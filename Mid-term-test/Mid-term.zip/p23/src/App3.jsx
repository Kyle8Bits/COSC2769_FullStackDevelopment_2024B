import React from 'react'
import SortedTable from './SortedTable';
import { useState } from 'react';

function App3() {


  const students =
  [ {id: 1, name: 'Alice', major: 'IT', GPA: 3.2},

    {id: 2, name: 'Bob', major: 'SE', GPA: 2.4},
    
    {id: 3, name: 'Farol', major: 'SE', GPA: 2.8},
    
    {id: 4, name: 'David', major: 'IT', GPA: 3.8},
    
    {id: 5, name: 'Mai Dang Khoa', major: 'IT', GPA: 3.0}
  ];

  const [currentList, setCurrent]= useState(students);

  function sortedName(){
    const sortName = currentList.sort((a, b) => {
        const nameA = a.name.toUpperCase(); // ignore upper and lowercase
        const nameB = b.name.toUpperCase(); // ignore upper and lowercase
        if (nameA < nameB) {
          return -1;
        }
        if (nameA > nameB) {
          return 1;
        }
      
        // names must be equal
        return 0;
    });

    setCurrent(sortName);

  }

  function sortedGPA(){
      const gpaSort = currentList.sort((a,b)=>
      a.GPA-b.GPA);

      setCurrent(gpaSort);
  }

  return (
    <div>
      <SortedTable studentList={currentList} sortedName={sortedName} sortedGPA={sortedGPA}/>
    </div>
  )
}

export default App3
